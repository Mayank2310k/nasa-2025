from flask import Flask, request, jsonify
import joblib
import numpy as np

app = Flask(__name__)

# Load your trained model (make sure exoplanet_model.pkl is in the same folder)
model = joblib.load("exoplanet_model.pkl")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    features = np.array([[ 
        data["orbital_period"], 
        data["radius"], 
        data["transit_duration"], 
        data["star_temp"] 
    ]])
    pred = model.predict(features)[0]
    prob = model.predict_proba(features).max()
    return jsonify({"prediction": str(pred), "confidence": float(prob)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)